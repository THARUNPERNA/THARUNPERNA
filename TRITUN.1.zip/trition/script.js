const signupForm = document.getElementById("signup-form");

signupForm.addEventListener("submit", function(event) {
  alert("Your request is submitted!!");
});
function car(){
    window.location.href = "sample.html";
   
 }